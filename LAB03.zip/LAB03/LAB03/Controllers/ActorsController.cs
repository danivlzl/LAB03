﻿// Controllers/ActorsController.cs
using LAB03.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace LAB03.Controllers
{
    public class ActorsController : Controller
    {
        private static List<Actor> actors = new List<Actor>
        {
            new Actor { Id = 1, Name = "Kevin", LastName = "Jonas", Country = "USA" },
            new Actor { Id = 2, Name = "Nick", LastName = "Jonas", Country = "USA" },
            new Actor { Id = 3, Name = "Joe", LastName = "Jonas", Country = "USA" },
            new Actor { Id = 4, Name = "Mon", LastName = "Laferte", Country = "Chile" },
            new Actor { Id = 5, Name = "Cris", LastName = "MJ", Country = "Chile" }
        };

        public IActionResult Index()
        {
            return View(actors);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Actor actor)
        {
            if (ModelState.IsValid)
            {
                actor.Id = actors.Count + 1;
                actors.Add(actor);
                return RedirectToAction(nameof(Index));
            }
            return View(actor);
        }

        public IActionResult Edit(int id)
        {
            var actor = actors.FirstOrDefault(a => a.Id == id);
            if (actor == null) return NotFound();
            return View(actor);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Actor actor)
        {
            if (id != actor.Id) return NotFound();
            if (ModelState.IsValid)
            {
                var index = actors.FindIndex(a => a.Id == id);
                if (index != -1)
                {
                    actors[index] = actor;
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(actor);
        }

        public IActionResult Delete(int id)
        {
            var actor = actors.FirstOrDefault(a => a.Id == id);
            if (actor == null) return NotFound();
            return View(actor);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var actor = actors.FirstOrDefault(a => a.Id == id);
            if (actor != null)
            {
                actors.Remove(actor);
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }

        public IActionResult Details(int id)
        {
            var actor = actors.FirstOrDefault(a => a.Id == id);
            if (actor == null) return NotFound();
            return View(actor);
        }
    }
}
